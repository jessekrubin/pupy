#!/usr/bin/env python
# -*- coding: utf-8 -*-
# JESSE RUBIN - pup == Biblioteca
from __future__ import absolute_import, division, generators, print_function
from sys import version_info
if version_info > (2, ): xrange = range

